import {
  Component,
  OnInit,
  ViewChild
} from '@angular/core';

import {
  OTranslateService,
  OFormComponent,
  OTableComponent
} from 'ontimize-web-ng2/ontimize';

import { Router, ActivatedRoute } from '@angular/router';

import { NavigationBarService } from '../../../shared';

@Component({
  moduleId: module.id,
  selector: 'data-detail',
  templateUrl: 'data-detail.component.html',
  styleUrls: ['data-detail.component.css']
})
export class DataDetailComponent implements OnInit {
  protected _tableDataColumns = 'DATA_ID;NAME;SURNAME';
  protected _tableData = [];

  @ViewChild('table')
  table: OTableComponent;

  constructor(
    protected navigationService: NavigationBarService,
    protected translateService: OTranslateService,
    protected router: Router,
    protected actRoute: ActivatedRoute
  ) {
  }

  ngOnInit() {
    let title = '';
    title = this.translateService.get('INTRODUCTION');
    this.navigationService.setTitle(title);
  }

  onFormDataLoaded(data) {
    let ignoredKeys = ['LAST_MODIFICATION_DATE', 'DATA_ID', 'CREATION_DATE', 'FORM_VERSION_ID'];
    let dataKeys = Object.keys(data);
    let dynamicData = {};
    for (let i = 0, len = dataKeys.length; i < len; i++) {
      if (ignoredKeys.indexOf(dataKeys[i]) === -1) {
        dynamicData[dataKeys[i]] = data[dataKeys[i]];
      }
    }
    this.tableDataColumns = Object.keys(dynamicData).join(';');
    this.table.reinitialize({
      columns: this.tableDataColumns,
      visibleColumns: this.tableDataColumns
    });
    this.tableData = [dynamicData];
  }

  set tableDataColumns(columns) {
    this._tableDataColumns = columns;
  }

  get tableDataColumns() {
    return this._tableDataColumns;
  }

  set tableData(data) {
    this._tableData = data;
  }

  get tableData() {
    return this._tableData;
  }
}
